import React from 'react'

const Documentation = () => {
  return (
    <div>
        <h1 className='font-bold  font-serif text-center mt-7 text-2xl'>Instructions</h1>
    </div>
  )
}

export default Documentation